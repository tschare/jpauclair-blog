// Draw class

#define AXRGB(a,r,g,b)          ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)|(((DWORD)(BYTE)(a))<<24)))
#define GetAValue(rgb)     (rgb >> 24)

static struct ID2D1Factory* ppD2DFactory = 0;
static HINSTANCE D2D1Library = 0;

class DRAW
	{
	private:

		bool dbuff;
#ifdef _WIN32
		int DrawingMode; // 0 GDI , 1 GDI+ , 2 Direct2D
		bool GdipQuality;
		HWND hh;
		HDC hDC; // Drawing DC
		HDC hActualDC; // Actual DC if double buffering
		Gdiplus::Graphics* g;
		Gdiplus::Font* fo;
		bool CreatedDC;
		bool CreatedActualDC;
		bool CreatedGraphics;
		HBITMAP hDoubleBufferBitmap;
		RECT FullRect;

		// Private Members
		HBITMAP CreateDIBBitmap(HDC hdc,int w,int h,int bits = 32);
		Gdiplus::Color DRAW :: GetGdipColor(unsigned long c);

		// Direct2D stuff
		HINSTANCE hD2Write;
		struct IDWriteFactory* CreateWriteFactory();
		struct ID2D1Factory* CreateD2Factory();

		struct IDWriteTextFormat* fo2d;
		struct ID2D1Factory* pD2DFactory;
		struct IWICImagingFactory* pImageFactory;
		struct IDWriteFactory* pWriteFactory;
		struct ID2D1HwndRenderTarget* pRT;			
		struct ID2D1SolidColorBrush* GetD2SolidBrush(unsigned long cc);

#endif



	public:

		// Constructors
#ifdef _WIN32
		void Init(HDC hhDC = 0,HDC hhActualDC = 0,Gdiplus::Graphics* hhG = 0);
		void Init2D();
		DRAW(HWND h,HDC hDC = 0,HDC hhActualDC = 0,Gdiplus::Graphics* hG = 0,int DrawingMode = 1,bool Qu = true,bool DB = true); 

		HDC GetTheDC() {return hDC;}
		void OnResize();
#endif

		~DRAW();
		void Start();
		void Execute();
		void Clean();
		static bool IsModeAvailable(int i);

		// Option Members
		void SetDoubleBuffering(bool);
		void SetHighQuality(bool);
		void SetDrawingMode(int);

		// Members
		void Line(int x1,int y1,int x2,int y2,int th = 1,unsigned long c = AXRGB(0xFF,0,0,0),unsigned int PenStyle = PS_SOLID);
		void Rect(RECT&ar,int th = 1,unsigned long c = AXRGB(0xFF,0,0,0),unsigned int PenStyle = PS_SOLID,bool Elp = false);
		void FilledRect(RECT&ar,unsigned long c = AXRGB(0xFF,0,0,0),bool Elp = false);
		void Polygon(POINT*p,int n,bool Close,int th = 1,unsigned long c = AXRGB(0xFF,0,0,0),unsigned int PenStyle = PS_SOLID);
		void FilledPolygon(POINT*p,int n,bool Close,unsigned long c = AXRGB(0xFF,0,0,0));
		void Ellipse(RECT&ar,int th = 1,unsigned long c = AXRGB(0xFF,0,0,0),unsigned int PenStyle = PS_SOLID);
		void FilledEllipse(RECT&ar,unsigned long c = AXRGB(0xFF,0,0,0));
		void Rect(int x1,int y1,int wi,int he,int th = 1,unsigned long c = AXRGB(0xFF,0,0,0),unsigned int PenStyle = PS_SOLID,bool Elp = false);
		void Ellipse(int x1,int y1,int wi,int he,int th = 1,unsigned long c = AXRGB(0xFF,0,0,0),unsigned int PenStyle = PS_SOLID);
		void FilledRect(int x1,int y1,int wi,int he,unsigned long c = AXRGB(0xFF,0,0,0),bool Elp = false);
		void FilledEllipse(int x1,int y1,int wi,int he,unsigned long c = AXRGB(0xFF,0,0,0));
		unsigned long TextSize(const wchar_t* txt,int l,unsigned long al,unsigned long lal);
		void DrawText(const wchar_t* txt,int l,int x,int y,int wi,int he,unsigned long al,unsigned long lal,unsigned long c = AXRGB(0xFF,0,0,0),int BreakMode = 1);
		void DrawText(const wchar_t* txt,int l,RECT&,unsigned long al,unsigned long lal,unsigned long c = AXRGB(0xFF,0,0,0),int BreakMode = 1);
#ifdef _WIN32
		void SetFont(HFONT hF1);
		void Image(int x1,int y1,LPWSTR fil,float Op = 1.0f);
		void Image(int x1,int y1,HINSTANCE h,LPWSTR n,LPWSTR typ = RT_BITMAP,float Op = 1.0f);
		void Image(int x1,int y1,HBITMAP hB,float Op = 1.0f,bool HasAlpha = 0);
		void Image(int x1,int y1,Gdiplus::Bitmap* b,bool HasAlpha = 0);
		HRESULT LoadResourceImage(HINSTANCE h,PCWSTR resourceName,PCWSTR resourceType,void**ppBitmap);
		HRESULT LoadFileImage(const LPWSTR f,void**ppBitmap);
#endif


	};