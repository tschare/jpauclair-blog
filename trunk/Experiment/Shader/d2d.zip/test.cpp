#define INITGUID
#define STRICT
#define _WIN32_WINNT 0x501
#define _WIN32_IE 0x600

#include <winsock2.h>
#include <windows.h>
#include <wininet.h>
#include <process.h>
#include <commctrl.h>
#include <gdiplus.h>
#include <stdio.h>
#include <shellapi.h>
#include <string>
#include <tchar.h>
using namespace std;
#pragma warning(disable : 4996)
#pragma warning(disable : 4267)
#pragma comment(lib,"ws2_32.lib")
#pragma comment(lib,"gdiplus.lib")
#pragma comment(lib,"msimg32.lib")

#ifndef DEFINE_ENUM_FLAG_OPERATORS
#ifdef __cplusplus
#define DEFINE_ENUM_FLAG_OPERATORS(ENUMTYPE) \
extern "C++" { \
inline ENUMTYPE operator | (ENUMTYPE a, ENUMTYPE b) { return ENUMTYPE(((int)a) | ((int)b)); } \
inline ENUMTYPE &operator |= (ENUMTYPE &a, ENUMTYPE b) { return (ENUMTYPE &)(((int &)a) |= ((int)b)); } \
inline ENUMTYPE operator & (ENUMTYPE a, ENUMTYPE b) { return ENUMTYPE(((int)a) & ((int)b)); } \
inline ENUMTYPE &operator &= (ENUMTYPE &a, ENUMTYPE b) { return (ENUMTYPE &)(((int &)a) &= ((int)b)); } \
inline ENUMTYPE operator ~ (ENUMTYPE a) { return ENUMTYPE(~((int)a)); } \
inline ENUMTYPE operator ^ (ENUMTYPE a, ENUMTYPE b) { return ENUMTYPE(((int)a) ^ ((int)b)); } \
inline ENUMTYPE &operator ^= (ENUMTYPE &a, ENUMTYPE b) { return (ENUMTYPE &)(((int &)a) ^= ((int)b)); } \
}
#else
#define DEFINE_ENUM_FLAG_OPERATORS(ENUMTYPE) // NOP, C allows these operators.
#endif
#endif
#include <d2d1.h>
#include <dwrite.h>
#include <wincodec.h>

enum
	{
	MESSAGE_HIDE2 = WM_USER + 1,
	};


#include "mydraw.h"

// ----
HWND MainWindow = 0;
HINSTANCE hAppInstance = 0;
HICON hIcon1;
HBITMAP hB = 0;
const TCHAR* ttitle = _T("App");

int me = 1; // method, 0 GDI, 1 GDI+ , 2 Direct2D

bool IsWindows7()
	{
	OSVERSIONINFOEX oex = {0};
	oex.dwOSVersionInfoSize = sizeof(oex);
	GetVersionEx((OSVERSIONINFO*)&oex);
	if (oex.dwMajorVersion >= 7)
		return true;
	if (oex.dwMajorVersion == 6 && oex.dwMinorVersion >= 1)
		return true;
	return false;
	}



// Performance Classes
wchar_t perfstring[50] = {0};
typedef void (*perffunc)(wchar_t*);
class PERF
	{
	private:
		unsigned long long PerfFrequency;
		unsigned long long t1;
		unsigned long long t2;
		perffunc pf;
	public:
		PERF(perffunc);
		~PERF();
		void Start();
		void End();
		void Beep(long double);
	};
// Performance stuff
PERF :: PERF(perffunc pf2)
	{
	LARGE_INTEGER* li = (LARGE_INTEGER*)&PerfFrequency;
	QueryPerformanceFrequency(li);

	pf = pf2;
	Start();
	}

PERF :: ~PERF()
	{
	End();
	}

void PERF :: End()
	{
	LARGE_INTEGER* li = (LARGE_INTEGER*)&t2;
	QueryPerformanceCounter(li);
	if (PerfFrequency != 0)
		Beep((t2 - t1)*1000.0f/(long double)PerfFrequency);
	}

void PERF :: Start()
	{
	LARGE_INTEGER* li = (LARGE_INTEGER*)&t1;
	QueryPerformanceCounter(li);
	}

void PERF :: Beep(long double x)
	{
	swprintf(perfstring,L"%.3f ms",x);
	SetWindowText(MainWindow,perfstring);
	}
PERF p(0);


DRAW* d = 0;

LRESULT CALLBACK Main_DP(HWND hh,UINT mm,WPARAM ww,LPARAM ll)
	{
	switch(mm)
		{
		case WM_COMMAND:
			{
			if(LOWORD(ww) >= 101 && LOWORD(ww) <= 103)
				{
				if (d)
					delete d;
				d = 0;
				}
			if (LOWORD(ww) == 101)
				me = 0;
			if (LOWORD(ww) == 102)
				me = 1;
			if (LOWORD(ww) == 103)
				me = 2;
			d = new DRAW(hh,0,0,0,me,true,true);
			if (LOWORD(ww) >= 101 && LOWORD(ww) <= 103)
				{
				InvalidateRect(hh,0,TRUE);
				UpdateWindow(hh);
				}
			return 0;
			}

		case WM_PAINT:
			{
			PAINTSTRUCT pS;
			BeginPaint(hh,&pS);
			RECT rc;
			GetClientRect(hh,&rc);


			if (!d)
				{
				if (IsWindows7())
					me = 2;
				else
					me = 1;
				d = new DRAW(hh,0,0,0,me,true,true);
				}

			p.Start();
			d->Start();
			d->FilledRect(0,0,rc.right,rc.bottom,AXRGB(0xFF,0xFF,0xFF,0xFF));
			d->Image(300,10,hB);
			d->Line(0,0,rc.right,rc.bottom,1,0xFF000000,PS_DOT);
			d->Line(0,rc.bottom,rc.right,0);
			d->Rect(50,50,50,50,1);
			d->FilledRect(150,120,50,50,AXRGB(0x5F,0xFF,0,0));
			d->Rect(200,200,100,50,1);
			d->DrawText(L"Hello",-1,200,200,100,50,Gdiplus::StringAlignmentCenter,Gdiplus::StringAlignmentCenter,AXRGB(0xB0,0x00,0x00,0xFF));
			d->Ellipse(10,10,40,40,1,0xFF000000,PS_DOT);
			d->FilledEllipse(300,500,40,40,0xFF000000);

			POINT p3[3] = {0};
			p3[0].x = 100; p3[0].y = 100;
			p3[1].x = 50; p3[1].y = 200;
			p3[2].x = 150; p3[2].y = 200;
			//d->Polygon(p3,3,true);
			d->FilledPolygon(p3,3,true,AXRGB(0x80,0xFF,0,0));
			d->Execute();
			p.End();

			EndPaint(hh,&pS);
			return 0;
			}

		
		case WM_CREATE:
			{



			break;
			}

		case WM_CLOSE:
			{
			DestroyWindow(hh);
			return 0;
			}

		case WM_DESTROY:
			{
			PostQuitMessage(0);
			return 0;
			}
		}
	return DefWindowProc(hh,mm,ww,ll);
	}



int __stdcall WinMain(HINSTANCE h,HINSTANCE,LPSTR tt,int)
	{
	WSADATA wData;
	WSAStartup(MAKEWORD(2, 2), &wData);
	CoInitializeEx(0,0);
	INITCOMMONCONTROLSEX icex = {0};
	icex.dwICC = ICC_LISTVIEW_CLASSES | ICC_DATE_CLASSES | ICC_WIN95_CLASSES;
	icex.dwSize = sizeof(icex);
	InitCommonControlsEx(&icex);
	InitCommonControls();
	hIcon1 = LoadIcon(h,_T("ICON_1"));
	ULONG_PTR tk = 0;
	Gdiplus::GdiplusStartupInput gsi;
	gsi.GdiplusVersion = 1;
	gsi.DebugEventCallback = 0;
	gsi.SuppressBackgroundThread = 0;
	gsi.SuppressExternalCodecs = 0;
	Gdiplus::GdiplusStartup(&tk,&gsi,0);
	hB = LoadBitmap(h,_T("B1"));

	hAppInstance = h;

	WNDCLASSEX wClass = {0};
	wClass.cbSize = sizeof(wClass);
	
	wClass.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW | CS_PARENTDC;
	wClass.lpfnWndProc = (WNDPROC)Main_DP;
	wClass.hInstance = h;
	wClass.hIcon = hIcon1;
	wClass.hCursor = LoadCursor(0, IDC_ARROW);
	wClass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wClass.lpszClassName = _T("CLASS");
	wClass.hIconSm = hIcon1;
	RegisterClassEx(&wClass);

	MainWindow = CreateWindowEx(0,
		_T("CLASS"),
		ttitle,
		WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS |
		WS_CLIPCHILDREN, CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT,CW_USEDEFAULT,0,LoadMenu(h,L"MENU_1"), h, 0);

	ShowWindow(MainWindow,SW_SHOW);


	MSG msg;

	while(GetMessage(&msg,0,0,0))
		{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
		}
	return 0;
	}