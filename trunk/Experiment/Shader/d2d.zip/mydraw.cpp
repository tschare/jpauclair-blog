#define STRICT
#define _WIN32_WINNT 0x501
#define _WIN32_IE 0x600

#include <winsock2.h>
#include <windows.h>
#include <gdiplus.h>
#include <wininet.h>
#include <process.h>
#include <commctrl.h>
#include <stdio.h>
#include <shellapi.h>
#include <tchar.h>
using namespace Gdiplus;

// If it is not defined (older sdk!)
#ifndef DEFINE_ENUM_FLAG_OPERATORS
#ifdef __cplusplus
#define DEFINE_ENUM_FLAG_OPERATORS(ENUMTYPE) \
extern "C++" { \
inline ENUMTYPE operator | (ENUMTYPE a, ENUMTYPE b) { return ENUMTYPE(((int)a) | ((int)b)); } \
inline ENUMTYPE &operator |= (ENUMTYPE &a, ENUMTYPE b) { return (ENUMTYPE &)(((int &)a) |= ((int)b)); } \
inline ENUMTYPE operator & (ENUMTYPE a, ENUMTYPE b) { return ENUMTYPE(((int)a) & ((int)b)); } \
inline ENUMTYPE &operator &= (ENUMTYPE &a, ENUMTYPE b) { return (ENUMTYPE &)(((int &)a) &= ((int)b)); } \
inline ENUMTYPE operator ~ (ENUMTYPE a) { return ENUMTYPE(~((int)a)); } \
inline ENUMTYPE operator ^ (ENUMTYPE a, ENUMTYPE b) { return ENUMTYPE(((int)a) ^ ((int)b)); } \
inline ENUMTYPE &operator ^= (ENUMTYPE &a, ENUMTYPE b) { return (ENUMTYPE &)(((int &)a) ^= ((int)b)); } \
}
#else
#define DEFINE_ENUM_FLAG_OPERATORS(ENUMTYPE) // NOP, C allows these operators.
#endif
#endif
#include <d2d1.h>
#include <dwrite.h>
#include <wincodec.h>

#pragma warning(disable : 4996)
#pragma warning(disable : 4267)

#include "mydraw.h"


// GDI wrappers of HBRUSH/hPEN
class SBRUSH
	{
	private:
		HBRUSH hB,hOldB;
		HDC hdc;

	public:
		SBRUSH(int c,int s = PS_SOLID,int h = HS_VERTICAL,HDC hDC = 0) 
			{
			LOGBRUSH lX = {s,c,h};
			hB = CreateBrushIndirect(&lX);
			hdc = 0;
			if (hDC)
				{
				hdc = hDC;
				hOldB = (HBRUSH)SelectObject(hDC,hB);
				}
			}
		~SBRUSH() {if (hdc) SelectObject(hdc,hOldB);DeleteObject(hB);}
		operator HBRUSH(){return hB;}
		operator void*(){return hB;}
	};
class SPEN
	{
	private:
		HPEN hP,hOldP;
		HDC hdc;
	public:
		SPEN(int c = 0,int S = 1,int Style = PS_SOLID,HDC hDC = 0)
			{
			hP = CreatePen(Style,S,c);
			hdc = 0;
			if (hDC)
				{
				hdc = hDC;
				hOldP = (HPEN)SelectObject(hDC,hP);
				}
			}
		SPEN(DWORD pS,DWORD pW,LOGBRUSH* pB,DWORD sc,DWORD* sty,HDC hDC = 0)
			{
			hP = ExtCreatePen(pS,pW,pB,sc,sty);
			hdc = 0;
			if (hDC)
				{
				hdc = hDC;
				hOldP = (HPEN)SelectObject(hDC,hP);
				}
			}
		~SPEN(){if (hdc) SelectObject(hdc,hOldP);DeleteObject(hP);}
		operator HPEN(){return hP;}
		operator void*(){return hP;}
	};

#ifdef _WIN32
DRAW :: DRAW(HWND h,HDC hhDC,HDC hhActualDC,Gdiplus::Graphics* hhG,int drm,bool Qu,bool DB)
	{
	hh = h;
	DrawingMode = drm;
	dbuff = DB;
	GdipQuality = Qu;
	if (DrawingMode == 2)
		Init2D();
	if (DrawingMode == 0 || DrawingMode == 1)
		Init(hhDC,hhActualDC,hhG);
	}
#endif

DRAW :: ~DRAW()
	{
	Clean();
	}

#ifdef _WIN32
HBITMAP DRAW :: CreateDIBBitmap(HDC hdc,int w,int h,int bits)
	{
	BITMAPINFO bi = {0};
	bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
	bi.bmiHeader.biWidth = w;
	bi.bmiHeader.biHeight = h;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = bits;
	bi.bmiHeader.biCompression = BI_RGB;
	void* pb = 0;
	HBITMAP hB = CreateDIBSection(hdc,&bi,DIB_PAL_COLORS,&pb,0,0);
	return hB;
	}
#endif

bool DRAW :: IsModeAvailable(int i)
	{
	if (i == 0)
		{
#ifdef _WIN32
		return true;
#else
		return false;
#endif
		}
	if (i == 1)
		{
#ifdef _WIN32
		return true;
#else
		return false;
#endif
		}
	if (i == 2)
		{
#ifdef _WIN32
		// Check presence of Direct2D
		HINSTANCE hX = LoadLibrary(L"D2D1.DLL");
		if (!hX)
			return false;
		FreeLibrary(hX);
		return true;
#else
		return false;
#endif
		}
	return false;
	}

void DRAW :: SetHighQuality(bool y)
	{
	GdipQuality = y;
	Clean();
	Init();
	}

void DRAW :: Clean()
	{
#ifdef _WIN32
	if (fo2d)
		fo2d->Release();
	fo2d = 0;
	if (fo)
		delete fo;
	fo = 0;
	if (CreatedGraphics)
		{
		delete g;
		}
	g = 0;
	if (CreatedDC)
		{
		if (dbuff)
			{
			DeleteDC(hDC);
			ReleaseDC(hh,hActualDC);
			}
		else
			ReleaseDC(hh,hDC);
		}
	hActualDC = 0;
	hDC = 0;
	if (hDoubleBufferBitmap)
		DeleteObject(hDoubleBufferBitmap);
	hDoubleBufferBitmap = 0;

	if (hD2Write)
		FreeLibrary(hD2Write);
	hD2Write = 0;
//	if (hD2Lib)
//		FreeLibrary(hD2Lib);
//	hD2Lib = 0;

	if (pWriteFactory)
		pWriteFactory->Release();
	pWriteFactory = 0;
	if (pImageFactory)
		pImageFactory->Release();
	pImageFactory = 0;
	if (pRT)
		pRT->Release();
	pRT = 0;
//	if (pD2DFactory)
//		pD2DFactory->Release();
//	pD2DFactory = 0;
#endif
	}



#ifdef _WIN32

IDWriteFactory* DRAW :: CreateWriteFactory()
	{
	HINSTANCE hX = hD2Write;
	if (!hX)
		return 0;

	typedef HRESULT (WINAPI *ddd)(DWRITE_FACTORY_TYPE,REFIID,IUnknown**);
	ddd D = (ddd)GetProcAddress(hX,"DWriteCreateFactory");
	if (!D)
		{
		FreeLibrary(hX);
		return 0;
		}

	IDWriteFactory* p = 0;
	D(DWRITE_FACTORY_TYPE_SHARED,__uuidof(IDWriteFactory),(IUnknown**)&p);
	return p;
/*

	IDWriteFactory* p = 0;
	DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED,__uuidof(IDWriteFactory),(IUnknown**)&p);
	return p;
*/
	}

ID2D1Factory* DRAW :: CreateD2Factory()
	{
	if (ppD2DFactory)
		return ppD2DFactory;

	HINSTANCE hX = D2D1Library;
	if (!hX)
		return 0;

	typedef HRESULT (WINAPI *ddd)(D2D1_FACTORY_TYPE,REFIID,const D2D1_FACTORY_OPTIONS*,void**);
	ddd D = (ddd)GetProcAddress(hX,"D2D1CreateFactory");
	if (!D)
		{
		FreeLibrary(hX);
		return 0;
		}

	ID2D1Factory* p = 0;
	D(D2D1_FACTORY_TYPE_SINGLE_THREADED,__uuidof(ID2D1Factory),0,(void**)&p);
	ppD2DFactory = p;
	return p;

/*
	ID2D1Factory* p = 0;
	D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED,__uuidof(ID2D1Factory),0,(void**)&p);
	ppD2DFactory = p;
	return p;
*/
	}

void DRAW :: Init2D()
	{
	hDC = 0;
	hActualDC = 0;
	g = 0;
	fo = 0;
	fo2d = 0;
	pD2DFactory = 0;
	pImageFactory = 0;
	pWriteFactory = 0;
	pRT = 0;
	hDoubleBufferBitmap = 0;
	if (!D2D1Library)
		D2D1Library = LoadLibrary(L"D2D1.DLL");
	hD2Write = LoadLibrary(L"DWRITE.DLL");
	pD2DFactory = CreateD2Factory();

	if (pD2DFactory)
		{
		// Create also an Imaging Factory
		CoCreateInstance(CLSID_WICImagingFactory,0,CLSCTX_ALL,__uuidof(IWICImagingFactory),(void**)&pImageFactory);

		// Create also a writing factory
		pWriteFactory = CreateWriteFactory();

		// Obtain the size of the drawing area.
		RECT rc = {0};
		GetClientRect(hh, &rc);

		// Create a Direct2D render target			
		pD2DFactory->CreateHwndRenderTarget(D2D1::RenderTargetProperties(),D2D1::HwndRenderTargetProperties(hh,D2D1::SizeU(rc.right - rc.left,rc.bottom - rc.top)),&pRT);
		}
	}
#endif

void DRAW :: Init(HDC hhDC,HDC hhActualDC,Gdiplus::Graphics* hhG)
	{
#ifdef _WIN32
	hDC = 0;
	hActualDC = 0;
	g = 0;
	fo = 0;
	fo = 0;
	fo2d = 0;
	pD2DFactory = 0;
	pImageFactory = 0;
	pWriteFactory = 0;
	pRT = 0;
	hDoubleBufferBitmap = 0;
	GetClientRect(hh,&FullRect);

	if (hDC)
		{
		CreatedDC = false;
		CreatedActualDC = false;
		hDC = hhDC;
		hActualDC = hhActualDC;
		}
	else
		{
		CreatedDC = true;
		CreatedActualDC = false;
		if (dbuff)
			{
			if (!hhActualDC)
				{
				hActualDC = GetDC(hh);
				CreatedActualDC = true;
				}
			else
				hActualDC = hhActualDC;
			hDoubleBufferBitmap = CreateDIBBitmap(hActualDC,FullRect.right,FullRect.bottom);
			hDC = CreateCompatibleDC(hActualDC);
			SelectObject(hDC,hDoubleBufferBitmap);
			}
		else
			{
			hActualDC = 0;
			hDC = GetDC(hh);
			}
		}
	if (DrawingMode == 1)
		{
		if (hhG)
			{
			CreatedGraphics = false;
			g = hhG;
			}
		else
			{
			CreatedGraphics = true;
			g = new Gdiplus::Graphics(hDC);
			if (GdipQuality)
				g->SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);
			}
		}
#endif
	}

void DRAW :: SetDrawingMode(int x)
	{
	DrawingMode = x;
	Clean();
	Init();
	}

void DRAW :: Start()
	{
	if (DrawingMode == 2)
		{
		if (pRT)
			pRT->BeginDraw();
		return; // Direct2D provides automatic dbuffering
		}
	}

void DRAW :: Execute()
	{
	// Execute if double buffering
	if (DrawingMode == 2)
		{
		HRESULT hr = 0;
		if (pRT)
			hr = pRT->EndDraw();
		return; // Direct2D provides automatic dbuffering
		}
	if (dbuff)
		{
		BitBlt(hActualDC,0,0,FullRect.right,FullRect.bottom,hDC,0,0,SRCCOPY);
		}
	}

void DRAW :: SetDoubleBuffering(bool x)
	{
	dbuff = x;
	Clean();
	Init();
	}

#ifdef _WIN32
void DRAW :: Image(int x1,int y1,Gdiplus::Bitmap* b,bool HasAlpha)
	{
	if (DrawingMode == 1)
		{
		g->DrawImage(b,x1,y1);
		}
	else
		{
		// Convert it to a HBITMAP
		HBITMAP hB = 0;
		b->GetHBITMAP(GetGdipColor(0xFFFFFFFF),&hB);
		Image(x1,y1,hB,HasAlpha);
		DeleteObject(hB);
		}
	}

Bitmap* CreateGdibitmapFromHBITMAP(HBITMAP hbmp) 
	{ 
	// Get width and height of source HBITMAP 
	BITMAP bm; 
	memset((void*)&bm, 0, sizeof(BITMAP)); 
	GetObject(hbmp, sizeof(BITMAP), (void*)&bm); 
	int width = bm.bmWidth; 
	int height = bm.bmHeight; 

	// Create a GDI+ bitmap of the same dimensions, with alpha. 
	Bitmap* copy = new Bitmap(width, height, PixelFormat32bppARGB); 

	//Get an HDC for this new Bitmap 
	Graphics* g = Graphics::FromImage(copy); 
	HDC copyHdc = g->GetHDC(); 

	HDC srcHdc = ::CreateCompatibleDC(0); 
	::SelectObject(srcHdc, hbmp); 

	//This loses all alpha: 
	//BOOL bbrv = ::BitBlt(copyHdc, 0, 0, width, height, srcHdc, 0,0, SRCCOPY); 

	//This retains some alpha (only where A == 0) 
	BLENDFUNCTION bf1; 
	bf1.BlendOp = AC_SRC_OVER; 
	bf1.BlendFlags = 0; 
	bf1.SourceConstantAlpha = 0xff; 
	bf1.AlphaFormat = AC_SRC_ALPHA; 
	BOOL abrv = ::AlphaBlend(copyHdc, 0, 0, width, height, srcHdc, 
		0, 0, width, height, bf1); 

	::DeleteDC(srcHdc); 

	g->ReleaseHDC(copyHdc); 

	return copy; 
	} 

HRESULT DRAW :: LoadFileImage(const LPWSTR f,void**ppBitmap)
	{
	HRESULT hr = S_OK;
	IWICImagingFactory *pIWICFactory = pImageFactory;
	IWICBitmapDecoder* spDecoder = 0;
	IWICBitmapFrameDecode* spSource = 0;
	IWICStream* spStream = 0;
	IWICFormatConverter* spConverter = 0;

	// Create a decoder for the stream
	pIWICFactory->CreateDecoderFromFilename(f,
		NULL,
		FILE_READ_DATA,WICDecodeMetadataCacheOnDemand,
		&spDecoder);
	if (!spDecoder)
		{
		return E_FAIL;
		}

	// Create the initial frame
	spDecoder->GetFrame(0,&spSource);
	if (!spSource)
		{
		spDecoder->Release();
		return E_FAIL;
		}

	// Format convert to 32bppPBGRA -- which Direct2D expects
	pIWICFactory->CreateFormatConverter(&spConverter);
	if (!spConverter)
		{
		spSource->Release();
		spDecoder->Release();
		return E_FAIL;
		}

	hr = spConverter->Initialize(
		spSource,
		GUID_WICPixelFormat32bppPBGRA,
		WICBitmapDitherTypeNone,
		NULL,
		0.f,
		WICBitmapPaletteTypeMedianCut
		);
	if (FAILED(hr))
		{
		spConverter->Release();
		spSource->Release();
		spDecoder->Release();
		return E_FAIL;
		}

	// Create a Direct2D bitmap from the WIC bitmap.
	pRT->CreateBitmapFromWicBitmap(
		spConverter,
		NULL,
		(ID2D1Bitmap**)ppBitmap
		);

	spConverter->Release();
	spSource->Release();
	spDecoder->Release();
	spStream->Release();

	if (!ppBitmap)
		return E_FAIL;
	return S_OK;
	}

HRESULT DRAW :: LoadResourceImage(HINSTANCE h,PCWSTR resourceName,PCWSTR resourceType,void**ppBitmap)
	{
	IWICImagingFactory *pIWICFactory = pImageFactory;
//	HRESULT hr;

	IWICBitmapDecoder* spDecoder = 0;
	IWICBitmapFrameDecode* spSource = 0;
	IWICStream* spStream = 0;
	IWICFormatConverter* spConverter = 0;

	HRSRC imageResHandle = NULL;
	HGLOBAL imageResDataHandle = NULL;
	void *pImageFile = NULL;
	DWORD imageFileSize = 0;

	// Locate the resource handle in our dll
	imageResHandle = FindResourceW(
		h,
		resourceName,
		resourceType
		);

	if (!imageResHandle)
		return E_FAIL;

	// Load the resource
	imageResDataHandle = LoadResource(
		h,
		imageResHandle
		);

	if (!imageResDataHandle)
		return E_FAIL;

	// Lock it to get a system memory pointer
	pImageFile = LockResource(
		imageResDataHandle
		);

	if (!pImageFile)
		return E_FAIL;

	// Calculate the size
	imageFileSize = SizeofResource(
		h,
		imageResHandle
		);

	if (!imageFileSize)
		return E_FAIL;

	// Create a WIC stream to map onto the memory
	pIWICFactory->CreateStream(&spStream);
	if (!spStream)
		return E_FAIL;

	HRESULT hr = 0;
	// Initialize the stream with the memory pointer and size
	hr = spStream->InitializeFromMemory(
		reinterpret_cast<BYTE*>(pImageFile),
		imageFileSize);
	if (FAILED(hr))
		{
		spStream->Release();
		return E_FAIL;
		}

	// Create a decoder for the stream
	pIWICFactory->CreateDecoderFromStream(
		spStream,
		NULL,
		WICDecodeMetadataCacheOnLoad,
		&spDecoder);
	if (!spDecoder)
		{
		spStream->Release();
		return E_FAIL;
		}

	// Create the initial frame
	spDecoder->GetFrame(0,&spSource);
	if (!spSource)
		{
		spDecoder->Release();
		spStream->Release();
		return E_FAIL;
		}

	// Format convert to 32bppPBGRA -- which Direct2D expects
	pIWICFactory->CreateFormatConverter(&spConverter);
	if (!spConverter)
		{
		spSource->Release();
		spDecoder->Release();
		spStream->Release();
		return E_FAIL;
		}

	hr = spConverter->Initialize(
		spSource,
		GUID_WICPixelFormat32bppPBGRA,
		WICBitmapDitherTypeNone,
		NULL,
		0.f,
		WICBitmapPaletteTypeMedianCut
		);
	if (FAILED(hr))
		{
		spConverter->Release();
		spSource->Release();
		spDecoder->Release();
		spStream->Release();
		return E_FAIL;
		}

	// Create a Direct2D bitmap from the WIC bitmap.
	pRT->CreateBitmapFromWicBitmap(
		spConverter,
		NULL,
		(ID2D1Bitmap**)ppBitmap
		);

	spConverter->Release();
	spSource->Release();
	spDecoder->Release();
	spStream->Release();

	if (!ppBitmap)
		return E_FAIL;
	return S_OK;
	}

void DRAW :: Image(int x1,int y1,LPWSTR fil,float Op)
	{
	if (DrawingMode == 0 || DrawingMode == 1)
		{
		HBITMAP hb = (HBITMAP)LoadImage(0,fil,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
		Image(x1,y1,hb);
		DeleteObject(hb);
		}
	if (DrawingMode == 2 && pRT)
		{
		ID2D1Bitmap* b = 0;
		LoadFileImage(fil,(void**)&b);
		if (b)
			{
			D2D1_SIZE_F r2 = b->GetSize();
			D2D1_RECT_F r;
			r.left = (FLOAT)x1;
			r.top = (FLOAT)y1;
			r.right = (FLOAT)(x1 + r2.width);
			r.bottom = (FLOAT)(y1 + r2.height);
			pRT->DrawBitmap(b,r,Op);
			b->Release();
			}
		}
	}

void DRAW :: Image(int x1,int y1,HINSTANCE h,LPWSTR n,LPWSTR ty,float Op)
	{
	if (DrawingMode == 0 || DrawingMode == 1)
		{
		HBITMAP hb = (HBITMAP)LoadImage(h,n,IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION);
		Image(x1,y1,hb);
		DeleteObject(hb);
		}
	if (DrawingMode == 2 && pRT)
		{
		ID2D1Bitmap* b = 0;
		LoadResourceImage(h,n,ty,(void**)&b);
		if (b)
			{
			D2D1_SIZE_F r2 = b->GetSize();
			D2D1_RECT_F r;
			r.left = (FLOAT)x1;
			r.top = (FLOAT)y1;
			r.right = (FLOAT)(x1 + r2.width);
			r.bottom = (FLOAT)(y1 + r2.height);
			pRT->DrawBitmap(b,r,Op);
			b->Release();
			}
		}
	}

void DRAW :: Image(int x1,int y1,HBITMAP hB,float Op,bool HasAlpha)
	{
	BITMAP bo;
	GetObject(hB,sizeof(bo),&bo);
	if (DrawingMode == 0)
		{
		// Draw this bitmap to the DC
		HDC hY = CreateCompatibleDC(hActualDC ? hActualDC : hDC);
		SelectObject(hY,hB);
		BitBlt(hDC,x1,y1,bo.bmWidth,bo.bmHeight,hY,0,0,SRCCOPY);
		DeleteDC(hY);
		}
	if (DrawingMode == 1)
		{
		if (!HasAlpha)
			{
			Gdiplus::Bitmap bi(hB,0);
			g->DrawImage(&bi,x1,y1);
			}
		else
			{
			Bitmap* abi = CreateGdibitmapFromHBITMAP(hB);
			g->DrawImage(abi,x1,y1);
			delete abi;
			}
		}
	if (DrawingMode == 2 && pRT)
		{
/*		Gdiplus::Bitmap* bi1 = new Gdiplus::Bitmap(hB,0);
		Gdiplus::Bitmap* bi2 = bi1->Clone(0,0,bo.bmWidth,bo.bmHeight,PixelFormat32bppPARGB);
		bi2->GetHBITMAP(Color(0,0,0,0),&hB);
		delete bi2;
		delete bi1;
*/

		WICBitmapAlphaChannelOption ao = WICBitmapUseAlpha;
		IWICBitmap* wb = 0;
		pImageFactory->CreateBitmapFromHBITMAP(hB,0,ao,&wb);
		if (!wb)
			{
//			DeleteObject(hB);
			return;
			}
		ID2D1Bitmap* b = 0;
		pRT->CreateBitmapFromWicBitmap(wb,0,&b);
		if (!b)
			{
			// Convert it
			IWICFormatConverter* spConverter = 0;
			pImageFactory->CreateFormatConverter(&spConverter);
			if (spConverter)
				{
				spConverter->Initialize(wb,GUID_WICPixelFormat32bppPBGRA,WICBitmapDitherTypeNone,NULL,0.f,WICBitmapPaletteTypeMedianCut);
				pRT->CreateBitmapFromWicBitmap(spConverter,0,&b);
				spConverter->Release();
				}
			wb->Release();
			}
		if (b)
			{
			D2D1_RECT_F r;
			r.left = (FLOAT)x1;
			r.top = (FLOAT)y1;
			r.right = (FLOAT)(x1 + bo.bmWidth);
			r.bottom = (FLOAT)(y1 + bo.bmHeight);
			pRT->DrawBitmap(b,r,Op);
			b->Release();
			}
//		DeleteObject(hB);
		}
	}

void DRAW :: Line(int x1,int y1,int x2,int y2,int th,unsigned long c,unsigned int PenStyle)
	{
	if (DrawingMode == 0) // GDI
		{
		SPEN sp(c & 0xFFFFFF,th,PenStyle,hDC);
		MoveToEx(hDC,x1,y1,0);
		LineTo(hDC,x2,y2);
		}
	if (DrawingMode == 1) // GDI+
		{
		Gdiplus::Pen pe(GetGdipColor(c),(Gdiplus::REAL)th);
		if (PenStyle == PS_DOT)
			pe.SetDashStyle(Gdiplus::DashStyleDot);
		if (PenStyle == PS_DASH)
			pe.SetDashStyle(Gdiplus::DashStyleDash);
		g->DrawLine(&pe,x1,y1,x2,y2);
		}
	if (DrawingMode == 2 && pRT) // Direct2D
		{
		HRESULT hr = 0;
		if (PenStyle == PS_DOT || PenStyle == PS_DASH)
			{
			if ((c & 0xFF000000) == 0xFF000000)
				c -= 0x4F000000;
			}
		ID2D1SolidColorBrush* b = GetD2SolidBrush(c);
		if (b)
			{
			D2D1_POINT_2F p1;
			p1.x = (FLOAT)x1;
			p1.y = (FLOAT)y1;
			D2D1_POINT_2F p2;
			p2.x = (FLOAT)x2;
			p2.y = (FLOAT)y2;
			pRT->DrawLine(p1,p2,b,(FLOAT)th);
			b->Release();
			}
		}
	}

void DRAW :: Ellipse(RECT&ar,int th,unsigned long c,unsigned int PenStyle)
	{
	Ellipse(ar.left,ar.top,ar.right - ar.left,ar.bottom - ar.top,th,c,PenStyle);
	}

void DRAW :: Ellipse(int x1,int y1,int wi,int he,int th,unsigned long c,unsigned int PenStyle)
	{
	Rect(x1,y1,wi,he,th,c,PenStyle,true);
	}

void DRAW :: FilledEllipse(int x1,int y1,int wi,int he,unsigned long c)
	{
	FilledRect(x1,y1,wi,he,c,true);
	}

void DRAW :: Rect(RECT&ar,int th,unsigned long c,unsigned int PenStyle,bool Elps)
	{
	Rect(ar.left,ar.top,ar.right - ar.left,ar.bottom - ar.top,th,c,PenStyle,Elps);
	}

void DRAW :: Rect(int x1,int y1,int wi,int he,int th,unsigned long c,unsigned int PenStyle,bool Elps)
	{
	if (DrawingMode == 0) // GDI
		{
		SPEN sp(c & 0xFFFFFF,th,PenStyle,hDC);
		HBRUSH hXX = (HBRUSH)SelectObject(hDC,GetStockObject(NULL_BRUSH));
		if (Elps)
			::Ellipse(hDC,x1,y1,x1 + wi,y1 + he);
		else
			Rectangle(hDC,x1,y1,x1 + wi,y1 + he);
		SelectObject(hDC,hXX);
		}
	if (DrawingMode == 1) // GDI+
		{
		Gdiplus::Pen pe(GetGdipColor(c),(Gdiplus::REAL)th);
		if (PenStyle == PS_DOT)
			pe.SetDashStyle(Gdiplus::DashStyleDot);
		if (PenStyle == PS_DASH)
			pe.SetDashStyle(Gdiplus::DashStyleDash);
		if (Elps)
			g->DrawEllipse(&pe,x1,y1,wi,he);
		else
			g->DrawRectangle(&pe,x1,y1,wi,he);
		}
	if (DrawingMode == 2) // Direct2D
		{
		HRESULT hr = 0;

		// Stroke
		D2D1_STROKE_STYLE_PROPERTIES p;
		memset(&p,0,sizeof(p));
		ID2D1StrokeStyle* str = 0;
/*		if (PenStyle == PS_DOT || PenStyle == PS_DASH)
			{
			pD2DFactory->CreateStrokeStyle(D2D1::StrokeStyleProperties(
				D2D1_CAP_STYLE_FLAT,
				D2D1_CAP_STYLE_FLAT,
				D2D1_CAP_STYLE_FLAT,
				D2D1_LINE_JOIN_MITER,
				5.0f,
				PenStyle == PS_DASH ? D2D1_DASH_STYLE_DASH : D2D1_DASH_STYLE_DOT,
				0.0f),0,0,&str);
			}
*/
		if (PenStyle == PS_DOT || PenStyle == PS_DASH)
			{
			if ((c & 0xFF000000) == 0xFF000000)
				c -= 0x4F000000;
			}
		ID2D1SolidColorBrush* b = GetD2SolidBrush(c);
		if (b)
			{
			D2D1_RECT_F r;
			D2D1_ELLIPSE r2;
			r.left = (FLOAT)x1;
			r.top = (FLOAT)y1;
			r.right = (FLOAT)(x1 + wi);
			r.bottom = (FLOAT)(y1 + he);
			
			if (Elps)
				{
				r2.point.x = r.left + (r.right - r.left)/2;
				r2.point.y = r.top + (r.bottom - r.top)/2;
				r2.radiusX = (r.right - r.left)/2;
				r2.radiusY = (r.bottom - r.top)/2;
				if (r2.radiusX > 0 && r2.radiusY > 0)
					pRT->DrawEllipse(r2,b,(FLOAT)th,str);
				}
			else
				{
//				char a1[100];
//				sprintf(a1,"%f %f %f %f",r.left,r.top,r.right,r.bottom);
//				MessageBoxA(0,a1,0,0);
				pRT->DrawRectangle(r,b,(FLOAT)th,str);
				}
			b->Release();
			}
		if (str)
			str->Release();
		}
	}

ID2D1SolidColorBrush* DRAW :: GetD2SolidBrush(unsigned long c)
	{
	if (!pRT)
		return 0;
	ID2D1SolidColorBrush* b = 0;
	D2D1_COLOR_F cc;
	cc.a = GetAValue(c)/255.0f;
	if (cc.a == 0)
		cc.a = 1.0f;
	cc.r = GetRValue(c)/255.0f;
	cc.g = GetGValue(c)/255.0f;
	cc.b = GetBValue(c)/255.0f;

//	c = 0x20FF0000;
//	D2D1_COLOR_F ax = D2D1::ColorF(c);
	pRT->CreateSolidColorBrush(cc,&b);
	return b;
	}

Gdiplus::Color DRAW :: GetGdipColor(unsigned long c)
	{
	int a = GetAValue(c);
	if (a == 0)
		a = 255;
	int r = GetRValue(c);
	int g = GetGValue(c);
	int b = GetBValue(c);
	Gdiplus::Color cc(a,r,g,b);
	return cc;
	}

void DRAW :: FilledRect(RECT&ar,unsigned long c,bool Elps)
	{
	FilledRect(ar.left,ar.top,ar.right - ar.left,ar.bottom - ar.top,c,Elps);
	}

void DRAW :: FilledEllipse(RECT&ar,unsigned long c)
	{
	FilledEllipse(ar.left,ar.top,ar.right - ar.left,ar.bottom - ar.top,c);
	}

void DRAW :: FilledRect(int x1,int y1,int wi,int he,unsigned long c,bool Elps)
	{
	if (DrawingMode == 0) // GDI
		{
		SPEN sp(c & 0xFFFFFF,1,PS_SOLID,hDC);
		SBRUSH sb(c & 0xFFFFFF);
		RECT a = {x1,y1,x1 + wi,y1 + he};
		if (Elps)
			::Ellipse(hDC,x1,y1,x1 + wi,y1 + he);
		else
			FillRect(hDC,&a,sb);
		}
	if (DrawingMode == 1) // GDI+
		{
		Gdiplus::SolidBrush br(GetGdipColor(c));
		if (Elps)
			g->FillEllipse(&br,x1,y1,wi,he);
		else
			g->FillRectangle(&br,x1,y1,wi,he);
		}
	if (DrawingMode == 2) // Direct2D
		{
		HRESULT hr = 0;
		ID2D1SolidColorBrush* b = GetD2SolidBrush(c);
		if (b)
			{
			D2D1_RECT_F r;
			D2D1_ELLIPSE r2;
			r.left = (FLOAT)x1;
			r.top = (FLOAT)y1;
			r.right = (FLOAT)(x1 + wi);
			r.bottom = (FLOAT)(y1 + he);
			if (Elps)
				{
				r2.point.x = r.left + (r.right - r.left)/2;
				r2.point.y = r.top + (r.bottom - r.top)/2;
				r2.radiusX = (r.right - r.left)/2;
				r2.radiusY = (r.bottom - r.top)/2;
				pRT->FillEllipse(r2,b);
				}
			else
				{
				pRT->FillRectangle(r,b);
				}
			b->Release();
			}
		}
	}

void DRAW :: DrawText(const wchar_t* txt,int l,RECT& ra,unsigned long al,unsigned long lal,unsigned long c,int BreakMode)
	{
	DrawText(txt,l,ra.left,ra.top,ra.right - ra.left,ra.bottom - ra.top,al,lal,c,BreakMode);
	}

void DRAW :: Polygon(POINT*p,int n,bool Close,int th,unsigned long c,unsigned int PenStyle)
	{
	if (n < 2 || !p)
		return;

	if (DrawingMode == 0)
		{
		HBRUSH hXX = (HBRUSH)SelectObject(hDC,GetStockObject(NULL_BRUSH));
		SPEN sp(c & 0xFFFFFF,th,PenStyle,hDC);
		::Polygon(hDC,p,n);
		SelectObject(hDC,hXX);
		}
	if (DrawingMode == 1)
		{
		}
	if (DrawingMode == 2 && pRT)
		{	
		D2D1_POINT_2F* pt =  new D2D1_POINT_2F[n];
		for(int i = 0 ; i < n ; i++)
			{
			pt[i].x = (FLOAT)p[i].x;
			pt[i].y = (FLOAT)p[i].y;
			}
		
		if (PenStyle == PS_DOT || PenStyle == PS_DASH)
			{
			if ((c & 0xFF000000) == 0xFF000000)
				c -= 0x4F000000;
			}
		ID2D1SolidColorBrush* b = GetD2SolidBrush(c);
		ID2D1PathGeometry* pg = 0;
		ID2D1GeometrySink* pgs = 0;
		pD2DFactory->CreatePathGeometry(&pg);
		if (pg)
			{
			pg->Open(&pgs);
			if (pgs)
				{
				D2D1_POINT_2F fb;
				fb.x = (FLOAT)pt[0].x;
				fb.y = (FLOAT)pt[0].y;
				D2D1_FIGURE_BEGIN fg = D2D1_FIGURE_BEGIN_HOLLOW;
				D2D1_FIGURE_END fe;
				if (Close)
					fe = D2D1_FIGURE_END_CLOSED;
				else 
					fe = D2D1_FIGURE_END_OPEN;
				pgs->BeginFigure(fb,fg);
				for(int i = 1 ; i < n ; i++)
					{
					D2D1_POINT_2F fu;
					fu.x = pt[i].x;
					fu.y = pt[i].y;
					pgs->AddLine(fu);
					}
				pgs->EndFigure(fe);
				pgs->Close();
				pgs->Release();
				}

			if (b)
				pRT->DrawGeometry(pg,b,(FLOAT)th);
			pg->Release();
			}
		if (b)
			b->Release();

		delete[] pt;
		}
	}

void DRAW :: FilledPolygon(POINT*p,int n,bool Close,unsigned long c)
	{
	if (DrawingMode == 0)
		{
		SPEN sp(c & 0xFFFFFF,1,PS_SOLID,hDC);
		SBRUSH sb(c & 0xFFFFFF,0,1,hDC);
		::Polygon(hDC,p,n);
		}
	if (DrawingMode == 1)
		{
		}
	if (DrawingMode == 2 && pRT)
		{	
		D2D1_POINT_2F* pt =  new D2D1_POINT_2F[n];
		for(int i = 0 ; i < n ; i++)
			{
			pt[i].x = (FLOAT)p[i].x;
			pt[i].y = (FLOAT)p[i].y;
			}
		ID2D1SolidColorBrush* b = GetD2SolidBrush(c);
		ID2D1PathGeometry* pg = 0;
		ID2D1GeometrySink* pgs = 0;
		pD2DFactory->CreatePathGeometry(&pg);
		if (pg)
			{
			pg->Open(&pgs);
			if (pgs)
				{
				D2D1_POINT_2F fb;
				fb.x = (FLOAT)pt[0].x;
				fb.y = (FLOAT)pt[0].y;
				D2D1_FIGURE_BEGIN fg = D2D1_FIGURE_BEGIN_FILLED;
				D2D1_FIGURE_END fe;
				if (Close)
					fe = D2D1_FIGURE_END_CLOSED;
				else 
					fe = D2D1_FIGURE_END_OPEN;
				pgs->BeginFigure(fb,fg);
				for(int i = 1 ; i < n ; i++)
					{
					D2D1_POINT_2F fu;
					fu.x = pt[i].x;
					fu.y = pt[i].y;
					pgs->AddLine(fu);
					}
				pgs->EndFigure(fe);
				pgs->Close();
				pgs->Release();
				}

			if (b)
				pRT->FillGeometry(pg,b,0);
			pg->Release();
			}
		if (b)
			b->Release();

		delete[] pt;
		}
	}


void DRAW :: DrawText(const wchar_t* txt,int l,int x,int y,int wi,int he,unsigned long al,unsigned long lal,unsigned long c,int BreakMode)
	{
	if (DrawingMode == 0)
		{
		SetBkMode(hDC,TRANSPARENT);
		}
	if (DrawingMode == 1)
		{
		Gdiplus::StringFormat sf;
		sf.SetAlignment((Gdiplus::StringAlignment)al);
		sf.SetLineAlignment((Gdiplus::StringAlignment)lal);
		if (BreakMode == 1)
			sf.SetFormatFlags(Gdiplus::StringFormatFlagsNoWrap);
		if (!fo)
			SetFont((HFONT)GetStockObject(DEFAULT_GUI_FONT));
		if (!fo)
			return;
		Gdiplus::PointF pt((Gdiplus::REAL)x,(Gdiplus::REAL)y);
		Gdiplus::SolidBrush br(GetGdipColor(c));
		if (wi != -1 && he != -1)
			{
			Gdiplus::RectF rt;
			rt.X = (Gdiplus::REAL)x;
			rt.Y = (Gdiplus::REAL)y;
			rt.Width = (Gdiplus::REAL)wi;
			rt.Height = (Gdiplus::REAL)he;
			g->DrawString(txt,l,fo,rt,&sf,&br);
			}
		else
			{
			g->DrawString(txt,l,fo,pt,&sf,&br);
			}
		}
	if (DrawingMode == 2 && pRT && pWriteFactory)
		{
		// Direct2D Text Drawing
		ID2D1SolidColorBrush* b = GetD2SolidBrush(c);
		if (b)
			{
			D2D1_RECT_F r;
			r.left = (FLOAT)x;
			r.top = (FLOAT)y;

			if (!fo2d)
				SetFont((HFONT)GetStockObject(DEFAULT_GUI_FONT));
			if (fo2d)
				{
				if (al == Gdiplus::StringAlignmentNear)
					{
					fo2d->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
					}
				if (al == Gdiplus::StringAlignmentCenter)
					{
					fo2d->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
					}
				if (al == Gdiplus::StringAlignmentFar)
					{
					fo2d->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_TRAILING);
					}
				if (lal == Gdiplus::StringAlignmentNear)
					{
					fo2d->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
					}
				if (lal == Gdiplus::StringAlignmentCenter)
					{
					fo2d->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
					}
				if (lal == Gdiplus::StringAlignmentFar)
					{
					fo2d->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_FAR);
					}

				if (wi == -1 || he == -1)
					{
					unsigned long ts = TextSize(txt,l,0,0);
					r.right = r.left + (ts & 0xFFFF);
					r.bottom = r.top + (ts >> 16);
					}
				else
					{
					r.right = r.left + wi;
					r.bottom = r.top + he;
					}

				pRT->DrawText(txt,l == -1 ? wcslen(txt) : l,fo2d,r,b);
				}
			b->Release();
			}
		}
	}


unsigned long DRAW :: TextSize(const wchar_t* txt,int l,unsigned long al,unsigned long lal)
	{
	if (DrawingMode == 0) // GDI
		{
/*		int flags = 0;
		if (al == Gdiplus::StringAlignmentCenter)
			flags |= DT_CENTER;
		if (lal == Gdiplus::StringAlignmentCenter)
			flags |= DT_VCENTER;
*/
		}
	if (DrawingMode == 1) // GDI+
		{
		if (!fo)
			SetFont((HFONT)GetStockObject(DEFAULT_GUI_FONT));
		if (!fo)
			return 0;
		Gdiplus::RectF lay(0,0,1000,1000);
		Gdiplus::RectF bou;
		Gdiplus::StringFormat sf;
		sf.SetAlignment((Gdiplus::StringAlignment)al);
		sf.SetLineAlignment((Gdiplus::StringAlignment)lal);
		g->MeasureString(txt,l,fo,lay,&sf,&bou,0,0);
		unsigned long r = 0;
		r = (unsigned long)bou.Width;
		r |= ((unsigned long)bou.Height << 16);
		return r;
		}
	if (DrawingMode == 2) // Direct2D
		{
		if (!fo2d)
			SetFont((HFONT)GetStockObject(DEFAULT_GUI_FONT));
		if (!fo2d)
			return 0;

		IDWriteTextLayout* lay = 0;
		pWriteFactory->CreateTextLayout(txt,l == -1 ? wcslen(txt) : l,fo2d,1000,1000,&lay);
		if (!lay)
			return 0;
		DWRITE_TEXT_METRICS m = {0};
		float fx = lay->GetMaxWidth();
		lay->GetMetrics(&m);
		lay->Release();
		int wi = (int)m.widthIncludingTrailingWhitespace;
		if (m.widthIncludingTrailingWhitespace > (float)wi)
			wi++;
		int he = (int)m.height;
		if (m.height > (float)he)
			he++;
		return (int)wi | ((int)he << 16);
		}
	return 0;
	}

void DRAW :: OnResize()
	{
	RECT rc;
	GetClientRect(hh,&rc);
	D2D1_SIZE_U us;
	us.width = rc.right;
	us.height = rc.bottom;
	if (pRT)
		pRT->Resize(us);
	}

void DRAW :: SetFont(HFONT hF)
	{
	if (DrawingMode == 0) // GDI
		{
		SelectObject(hDC,hF);
		}
	if (DrawingMode == 1) // GDI+
		{
		if (fo)
			delete fo;
		fo = 0;
		fo = new Gdiplus::Font(hDC,hF);
		if (fo->GetLastStatus() != Gdiplus::Ok)
			{
			hF = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
			delete fo;
			fo = new Gdiplus::Font(hDC,hF);
			}
		}
	if (DrawingMode == 2 && pWriteFactory) // Direct2D
		{
		if (fo2d)
			fo2d->Release();
		fo2d = 0;
		LOGFONT lf;
		GetObject(hF,sizeof(lf),&lf);
		DWRITE_FONT_STYLE fst = DWRITE_FONT_STYLE_NORMAL;
		if (lf.lfItalic)
			fst = DWRITE_FONT_STYLE_ITALIC;
		DWRITE_FONT_STRETCH fsr = DWRITE_FONT_STRETCH_NORMAL;
		FLOAT fs = (FLOAT)abs(lf.lfHeight);
		pWriteFactory->CreateTextFormat(lf.lfFaceName,0,lf.lfWeight > 500 ? DWRITE_FONT_WEIGHT_BOLD : DWRITE_FONT_WEIGHT_NORMAL,fst,fsr,fs,L"",&fo2d);
		}
	}

#endif


